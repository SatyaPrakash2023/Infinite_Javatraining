package com.java.Day2;

public class Looping3 {
public static void main(String[] args) 
{ 
   int x;
   x = 1; // starting value of x is 1.

// Execute the loop at least once .
   do {
      System.out.println(x); // print x value.
      x++; // increment x value by 1.
   } while(x <= 6); // This statement will execute as long as x <= 6.
 }
}