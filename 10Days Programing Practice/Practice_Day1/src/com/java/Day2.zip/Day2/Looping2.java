package com.java.Day2;

public class Looping2 {

	   public static void main(String args[]) {
	      int x = 10;

	      do {			//as it is do while loop it run at least once 
	         System.out.print("value of x : " + x );
	         x++;
	         System.out.print("\n");
	      }while( x < 20 );
	   }
	}