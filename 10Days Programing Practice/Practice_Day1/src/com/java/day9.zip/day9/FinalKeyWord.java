package com.java.day9;

public class FinalKeyWord{  
	  final int speedlimit;//blank final variable  
	    
	  FinalKeyWord(){  
	  speedlimit=70;  
	  System.out.println(speedlimit);  
	  }  
	  
	  public static void main(String args[]){  
	    new FinalKeyWord();  
	 }  
	}  