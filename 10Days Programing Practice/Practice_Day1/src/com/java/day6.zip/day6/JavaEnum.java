package com.java.day6;

public class JavaEnum {
	//Creating a enum
	enum Level {
	    LOW,
	    MEDIUM,
	    HIGH
	  }
	public static void main(String[] args) {
		//Call the enum method
	    Level myVar = Level.MEDIUM; 
	    System.out.println(myVar);
	  }
}