package com.java.day5;

class Final1{  
	 final int speedlimit=90;//final variable  
	 void run(){  
	//  speedlimit=400; //we cannot chahnge final variale vaue so it give error 
	 }  
	 public static void main(String args[]){  
		 Final1 obj=new  Final1();  
	 obj.run();  
	 }  
	}//end of class  