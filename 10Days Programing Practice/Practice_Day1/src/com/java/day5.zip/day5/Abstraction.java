package com.java.day5;


abstract class Bike{  
	  abstract void run();  //abstract class abstract method only define method here
	}  
class Honda4 extends Bike{  //inherited abstract class by Honda 
	void run(){//override method of super class implement here 
		System.out.println("running safely");
	}  
	
}  
public class Abstraction {
	public static void main(String args[]){  
		 Bike obj = new Honda4();  
		 obj.run();  
		}  
}
