package com.java.day4;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Exceptionhandaling8 {
	    public static void main(String[] args) {

	        DateFormat format = new SimpleDateFormat("MM, dd, yyyy");

	        try {
	            format.parse("01, 14, 2010");
	        } catch (ParseException e) {
	            System.err.println("ParseException caught!");
	            e.printStackTrace();
	        }
	    }
	}


