package com.java.jsf;

import java.util.Map;

import javax.faces.context.FacesContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

public class RecipentOldpassImpl {
	SessionFactory sf;
	Session session;

	public String ResetPassWordOldpasss(RecipentOldpassreset recipent) {
		Map<String,Object> sessionMap = 
				FacesContext.getCurrentInstance().getExternalContext().getSessionMap();		
		
		// Get the username from the session
		 String username = recipent.getUserName();
		 System.out.println("User name of recipent is "+username);
//        String username = "Shyam@123";
		String oldpass=EncryptPassword.getCode(recipent.getOldPassWord());
		sf = SessionHelper.getConnection();
		session = sf.openSession();
		Criteria cr=session.createCriteria(RecipentOldpassreset.class);
		cr.add(Restrictions.eq("userName", username));
		cr.add(Restrictions.eq("password", oldpass));
		RecipentOldpassreset recipentFound=(RecipentOldpassreset) cr.uniqueResult();
		if(recipentFound!=null) {
			String pass1=oldpass;
			String pass2=EncryptPassword.getCode(recipent.getPassword());
			String oldpassword=recipentFound.getPassword();
			if((!(pass1.contentEquals(pass2)))&& oldpass.equals(oldpassword)){
				sf = SessionHelper.getConnection();
				session = sf.openSession();
				Transaction trans = session.beginTransaction();
				String encr=EncryptPassword.getCode(recipent.getPassword());
				recipentFound.setPassword(encr);
				recipentFound.setStatus("Active");
				recipentFound.setOtp("");
				session.update(recipentFound);
				String email=recipentFound.getEmail();
				String subject = "Security alert";
				String messageText = "Hello,\n\nThe password for your LIC account "+email+" was changed."
						+ "if you didn't change it, you should recover your account.";
				MailSend.mailSend(email, subject, messageText);
				session.getTransaction().commit();
				sessionMap.put("sucessM", "Password updated sucessfully.");
				return"LoginProvider.jsp?faces-redirect=true";
			 }else {
				 
				 sessionMap.put("resetErr", "Password cannot be the same as the previous one.");
				return"RecipentResetPassWord.jsp?faces-redirect=true";
			}
			
		}else {
			sessionMap.put("passWordErr", "Your old password was typed incorrectly.");
		  return"RecipentResetPassWord.jsp?faces-redirect=true";
		}
	}
	
	
}	

