package com.java.jsf;

public interface PatientDao {
	String addPatient(Patient patient);
}



