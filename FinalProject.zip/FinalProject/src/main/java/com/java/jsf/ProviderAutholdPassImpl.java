package com.java.jsf;

import java.util.Map;

import javax.faces.context.FacesContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

public class ProviderAutholdPassImpl {
	SessionFactory sf;
	Session session;
	
	
	public String ResetPassWordOldpasss(ProviderOldPass provider) {
		Map<String,Object> sessionMap = 
				FacesContext.getCurrentInstance().getExternalContext().getSessionMap();		
		
		// Get the username from the session
		 String username = provider.getUserName();
//        String username = "Shyam@123";
		String oldpass=EncryptPassword.getCode(provider.getOldPassWord());
		sf = SessionHelper.getConnection();
		session = sf.openSession();
		Criteria cr=session.createCriteria(ProviderOldPass.class);
		cr.add(Restrictions.eq("userName", username));
		cr.add(Restrictions.eq("password", oldpass));
		ProviderOldPass provideFound=(ProviderOldPass) cr.uniqueResult();
		if(provideFound!=null) {
			String pass1=oldpass;
			String pass2=EncryptPassword.getCode(provider.getPassword());
			String oldpassword=provideFound.getPassword();
			if((!(pass1.contentEquals(pass2)))&& oldpass.equals(oldpassword)){
				sf = SessionHelper.getConnection();
				session = sf.openSession();
				Transaction trans = session.beginTransaction();
				String encr=EncryptPassword.getCode(provider.getPassword());
				provideFound.setPassword(encr);
				provideFound.setStatus("Active");
				provideFound.setOtp("");
				session.update(provideFound);
				String email=provideFound.getEmail();
				String subject = "Security alert";
				String messageText = "Hello,\n\nThe password for your LIC account "+email+" was changed."
						+ "if you didn't change it, you should recover your account.";
				MailSend.mailSend(email, subject, messageText);
				session.getTransaction().commit();
				return"LoginProvider.jsp?faces-redirect=true";
			 }else {
				 
				 sessionMap.put("resetErr", "Password cannot be the same as the previous one.");
				return"ResetPassWord.jsp?faces-redirect=true";
			}
			
		}else {
			sessionMap.put("passWordErr", "Your old password was typed incorrectly.");
		  return"ResetPassWord.jsp?faces-redirect=true";
		}
	}
}
