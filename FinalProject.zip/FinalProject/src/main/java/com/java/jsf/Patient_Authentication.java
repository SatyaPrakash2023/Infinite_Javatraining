package com.java.jsf;

public class Patient_Authentication {
	private int authId;
    private String uhid;
    private String username;
    private String passcode;
    private String otp;
    private String email;
    private String confirmPassword;
	public int getAuthId() {
		return authId;
	}
	public void setAuthId(int authId) {
		this.authId = authId;
	}
	public String getUhid() {
		return uhid;
	}
	public void setUhid(String uhid) {
		this.uhid = uhid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPasscode() {
		return passcode;
	}
	public void setPasscode(String passcode) {
		this.passcode = passcode;
	}
	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getConfirmPassword() {
		return confirmPassword;
	}
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	@Override
	public String toString() {
		return "Patient_Authentication [authId=" + authId + ", uhid=" + uhid + ", username=" + username + ", passcode="
				+ passcode + ", otp=" + otp + ", email=" + email + ", confirmPassword=" + confirmPassword + "]";
	}
	public Patient_Authentication(int authId, String uhid, String username, String passcode, String otp, String email,
			String confirmPassword) {
		super();
		this.authId = authId;
		this.uhid = uhid;
		this.username = username;
		this.passcode = passcode;
		this.otp = otp;
		this.email = email;
		this.confirmPassword = confirmPassword;
	}
	public Patient_Authentication() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
    
	
}
