package com.java.jsf;

public interface LoginDAO {
	public String verifyOtp(Login login);
	public String loginDao(Login login);
	public String loginWithOtp(Login login);
}
