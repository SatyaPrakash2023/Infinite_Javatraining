package com.java.jsf;

public interface PharmaLoginDAO {
	public String validateOtp(PharmacyLogin pharma);
	public String loginDao(PharmacyLogin pharma);
}
