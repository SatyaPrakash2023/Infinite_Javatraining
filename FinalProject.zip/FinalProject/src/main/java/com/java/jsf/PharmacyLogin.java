package com.java.jsf;

public class PharmacyLogin {
	private int authId;
	private String pharmId;
	private String email;
	private String password;
	private String status;
	private String otp;
	private String digit1;
	private String digit2;
	private String digit3;
	private String digit4;
	private String digit5;
	public int getAuthId() {
		return authId;
	}
	public void setAuthId(int authId) {
		this.authId = authId;
	}
	public String getPharmId() {
		return pharmId;
	}
	public void setPharmId(String pharmId) {
		this.pharmId = pharmId;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}
	public String getDigit1() {
		return digit1;
	}
	public void setDigit1(String digit1) {
		this.digit1 = digit1;
	}
	public String getDigit2() {
		return digit2;
	}
	public void setDigit2(String digit2) {
		this.digit2 = digit2;
	}
	public String getDigit3() {
		return digit3;
	}
	public void setDigit3(String digit3) {
		this.digit3 = digit3;
	}
	public String getDigit4() {
		return digit4;
	}
	public void setDigit4(String digit4) {
		this.digit4 = digit4;
	}
	public String getDigit5() {
		return digit5;
	}
	public void setDigit5(String digit5) {
		this.digit5 = digit5;
	}
	
	
}
