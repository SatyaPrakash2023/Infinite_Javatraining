package com.java.ejb;


import java.text.ParseException;
import java.util.Date;
import java.util.List; 

import javax.naming.NamingException;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

public class InsuranceSystemImpl {
	
	SessionFactory  sf;
	Session session;
	
	public 	List<Customer>showCustomer() throws NamingException{
		CustomerBeanRemote remote = RemoteHelper.lookupRemoteStatelessEmploy();
		return remote.showCustomer();
	}
	
	public String addCustomer(Customer customer) throws ParseException {
		sf = SessionHelper.getConnection();
		session = sf.openSession();
		Transaction trans = session.beginTransaction();
		String encr=EncryptPassword.getCode(customer.getPassCode());
		customer.setPassCode(encr);
//		Date obj = customer.getDateOfbirth();
//		System.out.println(obj);
//		java.sql.Date sqlDate = new java.sql.Date(obj.getTime());
//		customer.setDateOfbirth(sqlDate);
		session.save(customer);
		session.getTransaction().commit();

		
		int otp=GenerarteOtp.generateOtp();
		
		String subject = "Welcome to Life Insurance ";
		String messageText = "Hello,\n\nThank you for signing up in our LicApp. Your otp is "+otp+"It is "
				+ "valid for 10 minuetes only dont share your  otp with others";
		MailSend.mailSend(customer.getEmail(), subject, messageText);
		
		sf = SessionHelper.getConnection();
		session = sf.openSession();
		Transaction trans1 = session.beginTransaction();
		CustomerAuth cust1=new CustomerAuth();
		cust1.setCustId(customer.getCustId());
		cust1.setOtp(otp);
		session.save(cust1);
		session.getTransaction().commit();
			
		return"CustomerAuth.jsp?faces-redirect=true";
	}
	
	public  Customer getMailId(String custId) {
		sf = SessionHelper.getConnection();
		session = sf.openSession();
		Criteria cr=session.createCriteria(Customer.class);
		cr.add(Restrictions.eq("custId", custId));
		Customer cust=(Customer) cr.uniqueResult();
		
		return cust;
	}
	
	public  CustomerAuth getOtp(String custId) {
		sf = SessionHelper.getConnection();
		session = sf.openSession();
		Criteria cr=session.createCriteria(CustomerAuth.class);
		cr.add(Restrictions.eq("custId", custId));
		CustomerAuth custo=(CustomerAuth) cr.uniqueResult();
		
		return custo;
	}
	
	public String addAuthorization(CustomerAuth custA) {
		sf = SessionHelper.getConnection();
		session = sf.openSession();
		Transaction trans = session.beginTransaction();

		CustomerAuth customer_Auth=getOtp(custA.getCustId());
		Customer customera=getMailId(custA.getCustId());
		
		int otpTable=customer_Auth.getOtp();
		
		if(otpTable==custA.getOtp()) {
			String email=customera.getEmail();
			String subject = "Welcome to Life Insurance ";
			String messageText = "Hello,\n\n Your account has been successfully created.Congragulation you are now goldmember";
					
			MailSend.mailSend(email, subject, messageText);
			
			return"ResetPassWord.jsp?faces-redirect=true";
		}else {
			return"CustomerAuth.jsp?faces-redirect=true";

		}
		
		
		

	}
	
	public String resetPassWord(Customer cust) {
		
		Customer custp=getMailId(cust.getCustId());
		String pass1=cust.getPassCode();
		String pass2=cust.getRetypePassCode();
		if(pass1.equals(pass2)) {
			sf = SessionHelper.getConnection();
			session = sf.openSession();
			Transaction trans = session.beginTransaction();
			String encr=EncryptPassword.getCode(cust.getPassCode());
			custp.setPassCode(encr);
			custp.setRetypePassCode(encr);
			custp.setStatus("Active");		
			session.update(custp);
			session.getTransaction().commit();
			return"LoginCustomer.jsp?faces-redirect=true";
		 }
		else {
			return"ResetPassWord.jsp?faces-redirect=true";

		}	
	}
	
	public String LoginCustomer(Customer customer) {
		String encr=EncryptPassword.getCode(customer.getPassCode());
		sf = SessionHelper.getConnection();
		session = sf.openSession();
		Criteria cr = session.createCriteria(Customer.class);
		cr.add(Restrictions.eq("userName", customer.getUserName()));
		cr.add(Restrictions.eq("passCode", customer.getPassCode()));
		cr.setProjection(Projections.rowCount());
		long  count =(Long)cr.uniqueResult();
		if(count==1) {
			return"Dashboard.jsp?faces-redirect=true";
		}else {
			return"LoginCustomer.jsp?faces-redirect=true";
		}

	}
	
	
	
	
	
	
	
	
	
	
//	public String validateMe(Customer cust) {
//		String encr=EncryptPassword.getCode(cust.getCUS_PASSWORD());
//		Map<String,Object> sessionMap = 
//	FacesContext.getCurrentInstance().getExternalContext().getSessionMap();		
//		SessionFactory sf = SessionHelper.getConnection();
//		Session session = sf.openSession();
//		Criteria cr = session.createCriteria(Customer.class);
//		cr.add(Restrictions.eq("CUS_USERNAME", cust.getCUS_USERNAME()));
//		cr.add(Restrictions.eq("CUS_PASSWORD", cust.getCUS_PASSWORD()));
//		cr.setProjection(Projections.rowCount());
//		long  count =(Long)cr.uniqueResult();
//		if (count==1) {
//			sessionMap.put("loggedCustomer",  cust.getCUS_USERNAME());
//			sf = SessionHelper.getConnection();
//			session = sf.openSession();
//			cr = session.createCriteria(Customer.class);	
//			cr.add(Restrictions.eqOrIsNull("CUS_USERNAME", cust.getCUS_USERNAME()));
//			Customer customerFound = (Customer) cr.uniqueResult();
//			sessionMap.put("CUS_ID", customerFound.getCUS_ID());
//			return "Dashboard.jsp?faces-redirect=true";			
//		} else {
//			sessionMap.put("errorMessage", "Invalid Credentials...");
//			return "Login.jsp?faces-redirect=true";
//		}
//	}
	
	public List<Insurance>showInsurance(){
		sf = SessionHelper.getConnection();
		session = sf.openSession();
		Criteria cr = session.createCriteria(Insurance.class);
		List<Insurance> insList=cr.list();
		return insList;
	}
	
	public Insurance getInsurance(String insuranceId) {
		sf = SessionHelper.getConnection();
		session = sf.openSession();
		Criteria cr = session.createCriteria(Insurance.class);
		cr.add(Restrictions.eq("insuranceId", insuranceId));
		Insurance inssu=(Insurance) cr.uniqueResult();
		return inssu;
	}
	
	
	public String addCustomerPolicy(CustomerPolicy policy) {
		Insurance insFound=getInsurance(policy.getInsuranceId());
		if(policy.getPayMode()=="MONTHLY") {
			int amount=insFound.get
		}
	}
	


}
